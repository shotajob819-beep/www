import React from 'react';

export const AiPlanner: React.FC = () => {
  return null;
};